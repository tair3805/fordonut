package dev.esp;

import net.minecraft.client.gui.GuiGraphics;

/** Общие примитивы отрисовки в стиле Krypton: скруглённые панели, таблетки-переключатели, иконки. */
final class Ui {
    static final int ORANGE = 0xFFFF8A3D;
    static final int PANEL = 0xF0151519, HEADER = 0xF00C0C10, SEP = 0xFF0D0D11;
    static final int TEXT = 0xFFE4E4E8, DIM = 0xFF8E8E98;
    static final int TW = 26, TH = 12;

    /** Прямоугольник со скруглением 2px. */
    static void rounded(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x + 2, y, x + w - 2, y + h, c);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, c);
        g.fill(x, y + 2, x + w, y + h - 2, c);
    }

    /** Скруглены только верхние углы. */
    static void roundedTop(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x + 2, y, x + w - 2, y + 1, c);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, c);
        g.fill(x, y + 2, x + w, y + h, c);
    }

    /** Скруглённый прямоугольник с радиусом r (для r = h/2 получается "таблетка"). */
    static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        for (int dy = 0; dy < h; dy++) {
            int d = Math.min(dy, h - 1 - dy);
            int inset = 0;
            if (d < r) {
                double dyc = r - d - 0.5;
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dyc * dyc)));
            }
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, c);
        }
    }

    /** Пиксельный переключатель: прямоугольная плашка со срезанными углами и квадратный ползунок. */
    static void pill(GuiGraphics g, int x, int y, boolean on) {
        int c = on ? ORANGE : 0xFF2B2B34;
        g.fill(x + 1, y, x + TW - 1, y + TH, c);
        g.fill(x, y + 1, x + TW, y + TH - 1, c);

        int kd = TH - 4, ky = y + 2;
        int kx = on ? x + TW - kd - 2 : x + 2;
        int kc = on ? 0xFFFFFFFF : 0xFFD0D0D8;
        g.fill(kx + 1, ky, kx + kd - 1, ky + kd, kc);
        g.fill(kx, ky + 1, kx + kd, ky + kd - 1, kc);
    }

    static int iconColor(String title) {
        return switch (title) {
            case "COMBAT" -> 0xFF9AA0AA;
            case "MOVEMENT" -> 0xFF5CD68A;
            case "RENDER" -> 0xFF5CC8E8;
            case "PLAYER" -> 0xFFB06CFF;
            case "MISC" -> 0xFFE0503C;
            default -> 0xFFE8C040;
        };
    }

    static void icon(GuiGraphics g, int x, int y, String title) {
        int c = iconColor(title);
        rounded(g, x, y, 10, 10, 0xFF1E1E24);
        rounded(g, x + 2, y + 2, 6, 6, c);
    }
}
