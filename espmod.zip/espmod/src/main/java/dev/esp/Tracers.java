package dev.esp;

import java.util.Map;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Трейсеры: линии от низа экрана к целям, проекция считается вручную (2D-оверлей). */
public final class Tracers {
    private static final int MAX_LINES = 80;

    public static void render(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.options.hideGui) return;
        if (!Config.blockTracers && !Config.playerTracers && !Config.mobTracers && !Config.itemTracers) return;
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;

        float pt = dt.getGameTimeDeltaPartialTick(false);
        Vec3 eye = cam.getEyePosition(pt);
        double yaw = Math.toRadians(cam.getViewYRot(pt)), pitch = Math.toRadians(cam.getViewXRot(pt));
        Vec3 f = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 r = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 u = r.cross(f);
        int w = g.guiWidth(), h = g.guiHeight();
        double tan = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) w / h;

        int lines = 0;
        if (Config.playerTracers) {
            for (Player p : mc.level.players()) {
                if (p == mc.player || p == cam || lines >= MAX_LINES) continue;
                Vec3 t = p.getPosition(pt).add(0, p.getBbHeight() / 2, 0);
                line(g, t.subtract(eye), r, u, f, tan, aspect, w, h, 0xFF000000 | Config.PLAYER_COLOR);
                lines++;
            }
        }
        if (Config.mobTracers || Config.itemTracers) {
            for (Entity e : mc.level.entitiesForRendering()) {
                if (lines >= MAX_LINES) break;
                if (e == cam || e == mc.player) continue;
                boolean m = Config.mobTracers && e instanceof Enemy;
                boolean it = Config.itemTracers && e instanceof ItemEntity;
                if (!m && !it) continue;
                Vec3 t = e.getPosition(pt).add(0, e.getBbHeight() / 2, 0);
                line(g, t.subtract(eye), r, u, f, tan, aspect, w, h, m ? 0xFFFF5566 : 0xFFFFD83D);
                lines++;
            }
        }
        if (Config.blockTracers) {
            int n = 0;
            for (Map.Entry<BlockPos, Integer> e : Config.blockTracers ? BlockEsp.TARGETS.entrySet() : Map.<BlockPos, Integer>of().entrySet()) {
                if (n++ >= MAX_LINES) break;
                BlockPos b = e.getKey();
                Vec3 t = new Vec3(b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5);
                line(g, t.subtract(eye), r, u, f, tan, aspect, w, h, 0xFF000000 | e.getValue());
            }
        }
    }

    private static void line(GuiGraphics g, Vec3 d, Vec3 r, Vec3 u, Vec3 f, double tan, double aspect, int w, int h, int color) {
        double xc = d.dot(r), yc = d.dot(u), zc = d.dot(f);
        double sx, sy;
        if (zc > 0.1) {
            sx = (xc / (zc * tan * aspect) + 1) / 2 * w;
            sy = (1 - yc / (zc * tan)) / 2 * h;
        } else {
            double len = Math.hypot(xc, yc);
            if (len < 1e-4) { xc = 1; yc = 0; len = 1; }
            sx = w / 2.0 + xc / len * w;
            sy = h / 2.0 - yc / len * h;
        }
        sx = Math.max(0, Math.min(w - 1, sx));
        sy = Math.max(0, Math.min(h - 1, sy));
        double x0 = w / 2.0, y0 = h - 1;
        double dx = sx - x0, dy = sy - y0;
        int steps = (int) Math.max(Math.abs(dx), Math.abs(dy));
        if (steps < 1) return;
        for (int i = 0; i <= steps; i++) {
            int x = (int) (x0 + dx * i / steps), y = (int) (y0 + dy * i / steps);
            g.fill(x, y, x + 1, y + 1, color);
        }
    }
}
