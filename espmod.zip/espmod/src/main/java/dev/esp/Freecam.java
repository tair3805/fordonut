package dev.esp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.phys.Vec3;

public final class Freecam {
    public static boolean active = false;
    private static RemotePlayer cam;
    private static float savedYaw, savedPitch;
    public static double speed = 0.8;

    public static void toggle(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        if (!active) {
            savedYaw = mc.player.getYRot();
            savedPitch = mc.player.getXRot();
            cam = new RemotePlayer(mc.level, mc.player.getGameProfile());
            cam.copyPosition(mc.player);
            cam.setOldPosAndRot();
            mc.setCameraEntity(cam);
            active = true;
        } else {
            off(mc);
        }
    }

    public static void off(Minecraft mc) {
        if (!active) return;
        active = false;
        if (mc.player != null) {
            mc.setCameraEntity(mc.player);
            mc.player.setYRot(savedYaw);
            mc.player.setXRot(savedPitch);
        }
        cam = null;
    }

    public static void tick(Minecraft mc) {
        if (!active) return;
        if (mc.player == null || mc.level == null || cam == null) { active = false; cam = null; return; }
        cam.setOldPosAndRot();
        cam.setYRot(mc.player.getYRot());
        cam.setXRot(mc.player.getXRot());

        var o = mc.options;
        Vec3 look = cam.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 move = Vec3.ZERO;
        if (o.keyUp.isDown()) move = move.add(look);
        if (o.keyDown.isDown()) move = move.subtract(look);
        if (o.keyRight.isDown()) move = move.add(right);
        if (o.keyLeft.isDown()) move = move.subtract(right);
        if (o.keyJump.isDown()) move = move.add(0, 1, 0);
        if (o.keyShift.isDown()) move = move.subtract(0, 1, 0);
        if (move.lengthSqr() > 0) cam.setPos(cam.position().add(move.normalize().scale(speed)));
    }
}
