package dev.esp;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Окно настроек модуля: бинд, режим бинда и параметры. */
public class ModuleScreen extends Screen {
    private static final int W = 190, RH = 16, HH = 18;
    private final Screen parent;
    private final Mods.Mod mod;
    private boolean capturing, armed;
    private int left, top, H;

    public ModuleScreen(Screen parent, Mods.Mod mod) {
        super(Component.literal(mod.name));
        this.parent = parent;
        this.mod = mod;
    }

    private int rowY(int i) { return top + HH + i * RH; }

    private void hit(int x, int y, int w, Runnable r) {
        addRenderableWidget(Button.builder(Component.empty(), b -> r.run()).bounds(x + 1, y + 1, w - 2, RH - 2).build());
    }

    @Override
    protected void init() {
        int rows = 2 + mod.settings.size();
        H = HH + rows * RH + 2;
        left = (width - W) / 2;
        top = (height - H) / 2;

        hit(left, rowY(0), W, () -> { capturing = true; armed = false; });
        hit(left, rowY(1), W, () -> mod.hold = !mod.hold);
        for (int i = 0; i < mod.settings.size(); i++) {
            Mods.Setting s = mod.settings.get(i);
            int y = rowY(2 + i);
            if (s.isBool) hit(left, y, W, () -> s.setBool(!s.getBool()));
            else {
                hit(left + W - 70, y, 16, () -> s.bump(-1));
                hit(left + W - 18, y, 16, () -> s.bump(1));
            }
        }
    }

    @Override
    public void tick() {
        if (!capturing) return;
        boolean any = false;
        for (int k = 32; k <= 348; k++) if (Mods.isDown(minecraft, k)) { any = true; break; }
        if (!armed) { if (!any) armed = true; return; }
        for (int k = 32; k <= 348; k++) {
            if (!Mods.isDown(minecraft, k)) continue;
            mod.key = (k == GLFW.GLFW_KEY_DELETE || k == GLFW.GLFW_KEY_BACKSPACE) ? -1 : k;
            capturing = false;
            Mods.save();
            return;
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x55000000);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);

        Ui.rounded(g, left, top, W, H, Ui.PANEL);
        Ui.roundedTop(g, left, top, W, HH, Ui.HEADER);
        g.drawString(font, Component.literal(mod.name).withColor(Ui.TEXT), left + 8, top + 5, 0xFFFFFFFF);

        int total = 2 + mod.settings.size();
        for (int i = 0; i < total; i++) {
            int y = rowY(i);
            boolean hover = mx >= left && mx < left + W && my >= y && my < y + RH;
            if (hover) g.fill(left + 1, y, left + W - 1, y + RH, 0x14FFFFFF);
            if (i > 0) g.fill(left, y, left + W, y + 1, Ui.SEP);
        }

        row(g, 0, "Бинд", capturing ? "нажмите клавишу…" : Mods.keyName(mod.key));
        row(g, 1, "Режим бинда", mod.hold ? "Удержание" : "Переключ.");

        for (int i = 0; i < mod.settings.size(); i++) {
            Mods.Setting s = mod.settings.get(i);
            int y = rowY(2 + i);
            g.drawString(font, Component.literal(s.name).withColor(Ui.TEXT), left + 8, y + 4, 0xFFFFFFFF);
            if (s.isBool) {
                Ui.pill(g, left + W - Ui.TW - 6, y + 2, s.getBool());
            } else {
                g.drawString(font, Component.literal("−").withColor(Ui.DIM), left + W - 65, y + 4, 0xFFFFFFFF);
                g.drawString(font, Component.literal("+").withColor(Ui.DIM), left + W - 13, y + 4, 0xFFFFFFFF);
                String v = s.display();
                int cx = left + W - 40;
                g.drawString(font, Component.literal(v).withColor(0xFF9F5A), cx - font.width(v) / 2 + 8, y + 4, 0xFFFFFFFF);
            }
        }
        g.drawCenteredString(font, Component.literal("Delete — сбросить бинд  •  Esc — назад").withColor(0x6B6F80),
            width / 2, top + H + 8, 0xFFFFFFFF);
    }

    private void row(GuiGraphics g, int i, String label, String value) {
        int y = rowY(i);
        g.drawString(font, Component.literal(label).withColor(0xFFE4E4E8), left + 8, y + 4, 0xFFFFFFFF);
        g.drawString(font, Component.literal(value).withColor(0xFF9F5A), left + W - 8 - font.width(value), y + 4, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        Mods.save();
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
