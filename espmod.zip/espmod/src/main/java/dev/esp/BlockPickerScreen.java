package dev.esp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;

/** Выбор любых блоков игры: поиск + страницы. */
public class BlockPickerScreen extends Screen {
    private static final int PER_PAGE = 16, COL_W = 150, ROW_H = 22;
    private static List<Block> all;

    private final Screen parent;
    private final List<AbstractWidget> listWidgets = new ArrayList<>();
    private List<Object> filtered = new ArrayList<>();
    private EditBox search;
    private String query = "";
    private int pageIdx = 0;

    public BlockPickerScreen(Screen parent) {
        super(Component.literal("Выбор блоков"));
        this.parent = parent;
        if (all == null) {
            all = BuiltInRegistries.BLOCK.stream()
                .filter(b -> !b.defaultBlockState().isAir())
                .sorted(Comparator.comparing((Block b) -> BuiltInRegistries.BLOCK.getKey(b).getPath()))
                .toList();
        }
    }

    private static String name(Block b) { return BuiltInRegistries.BLOCK.getKey(b).getPath(); }

    @Override
    protected void init() {
        int cx = width / 2;
        search = new EditBox(font, cx - COL_W - 2, 10, COL_W * 2 + 4, 18, Component.literal("Поиск"));
        search.setValue(query);
        search.setHint(Component.literal("Поиск блока…"));
        search.setResponder(s -> { query = s; pageIdx = 0; rebuildList(); });
        addRenderableWidget(search);

        int by = 36 + (PER_PAGE / 2) * ROW_H + 6;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { pageIdx--; rebuildList(); })
            .bounds(cx - COL_W - 2, by, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { pageIdx++; rebuildList(); })
            .bounds(cx + COL_W + 2 - 40, by, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Очистить"), b -> {
            Config.CUSTOM.clear();
            Config.ENABLED.clear();
            rebuildList();
        }).bounds(cx - 50, by, 48, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
            .bounds(cx + 2, by, 48, 20).build());
        rebuildList();
    }

    private void rebuildList() {
        for (AbstractWidget w : listWidgets) removeWidget(w);
        listWidgets.clear();

        String q = query.toLowerCase();
        List<Object> list = new ArrayList<>();
        for (Config.Group gr : Config.GROUPS) if (gr.name().toLowerCase().contains(q)) list.add(gr);
        for (Block b : all) if (name(b).contains(q)) list.add(b);
        filtered = list;

        int pages = Math.max(1, (filtered.size() + PER_PAGE - 1) / PER_PAGE);
        pageIdx = Math.max(0, Math.min(pageIdx, pages - 1));

        int cx = width / 2;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = pageIdx * PER_PAGE + i;
            if (idx >= filtered.size()) break;
            Object o = filtered.get(idx);
            Component label;
            Runnable act;
            if (o instanceof Config.Group gr) {
                boolean on = Config.ENABLED.contains(gr);
                label = Component.literal(on ? "✔ " : "★ ").withColor(on ? 0xFFFFFF : 0x8A8F99)
                    .append(Component.literal(gr.name() + " (группа)").withColor(on ? 0xFFFFFF : 0xB8B8BE));
                act = () -> { if (!Config.ENABLED.remove(gr)) Config.ENABLED.add(gr); };
            } else {
                Block blk = (Block) o;
                boolean on = Config.CUSTOM.contains(blk);
                label = Component.literal(on ? "✔ " : "○ ").withColor(on ? 0xFFFFFF : 0x8A8F99)
                    .append(Component.literal(name(blk)).withColor(on ? 0xFFFFFF : 0xB8B8BE));
                act = () -> { if (!Config.CUSTOM.remove(blk)) Config.CUSTOM.add(blk); };
            }
            int x = cx - COL_W - 2 + (i % 2) * (COL_W + 4);
            int y = 36 + (i / 2) * ROW_H;
            Button btn = Button.builder(label, bt -> { act.run(); rebuildList(); }).bounds(x, y, COL_W, 20).build();
            addRenderableWidget(btn);
            listWidgets.add(btn);
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int pages = Math.max(1, (filtered.size() + PER_PAGE - 1) / PER_PAGE);
        String info = "Стр. " + (pageIdx + 1) + "/" + pages + "  •  найдено " + filtered.size() + "  •  выбрано " + (Config.CUSTOM.size() + Config.ENABLED.size());
        g.drawCenteredString(font, Component.literal(info).withColor(0x9AA0A6), width / 2,
            36 + (PER_PAGE / 2) * ROW_H + 32, 0xFFFFFFFF);
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }
}
