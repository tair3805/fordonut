package dev.esp;

import com.mojang.blaze3d.platform.InputConstants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

/** Реестр модулей: настройки, бинды, сохранение в config/espmod.properties. */
public final class Mods {
    public enum Cat { COMBAT, MOVEMENT, PLAYER, RENDER, MISC }

    public static final class Setting {
        public final String name;
        public final boolean isBool;
        public final double min, max, step;
        private final DoubleSupplier getD; private final DoubleConsumer setD;
        private final BooleanSupplier getB; private final Consumer<Boolean> setB;

        private Setting(String n, boolean b, double min, double max, double step,
                        DoubleSupplier gd, DoubleConsumer sd, BooleanSupplier gb, Consumer<Boolean> sb) {
            name = n; isBool = b; this.min = min; this.max = max; this.step = step;
            getD = gd; setD = sd; getB = gb; setB = sb;
        }
        public static Setting num(String n, double min, double max, double step, DoubleSupplier g, DoubleConsumer s) {
            return new Setting(n, false, min, max, step, g, s, null, null);
        }
        public static Setting bool(String n, BooleanSupplier g, Consumer<Boolean> s) {
            return new Setting(n, true, 0, 0, 0, null, null, g, s);
        }
        public boolean getBool() { return getB.getAsBoolean(); }
        public void setBool(boolean v) { setB.accept(v); }
        public double getNum() { return getD.getAsDouble(); }
        public void setNum(double v) { setD.accept(Math.max(min, Math.min(max, Math.round(v * 1000) / 1000.0))); }
        public void bump(int dir) { setNum(getNum() + dir * step); }
        public String display() {
            double v = getNum();
            return step >= 1 ? String.valueOf((int) Math.round(v)) : String.format(Locale.ROOT, "%.2f", v);
        }
    }

    public static final class Mod {
        public final String name; public final Cat cat;
        public final BooleanSupplier get; public final Consumer<Boolean> set;
        public final List<Setting> settings = new ArrayList<>();
        public int key = -1;
        public boolean hold = false;
        boolean wasDown;
        Mod(String n, Cat c, BooleanSupplier g, Consumer<Boolean> s) { name = n; cat = c; get = g; set = s; }
        public void toggle() { set.accept(!get.getAsBoolean()); }
    }

    public static final List<Mod> ALL = new ArrayList<>();

    private static void add(Cat c, String n, BooleanSupplier g, Consumer<Boolean> s, Setting... st) {
        Mod m = new Mod(n, c, g, s);
        m.settings.addAll(List.of(st));
        ALL.add(m);
    }

    static {
        // ---------- COMBAT ----------
        add(Cat.COMBAT, "Kill Aura", () -> Modules.killAura, v -> Modules.killAura = v,
            Setting.num("Дальность", 2, 6, 0.5, () -> Modules.killRange, v -> Modules.killRange = v),
            Setting.bool("Игроки", () -> Modules.killPlayers, v -> Modules.killPlayers = v));
        add(Cat.COMBAT, "Auto Clicker", () -> Modules.autoClicker, v -> Modules.autoClicker = v,
            Setting.num("CPS", 1, 20, 1, () -> Modules.cps, v -> Modules.cps = (int) v));
        add(Cat.COMBAT, "Trigger Bot", () -> Modules.triggerBot, v -> Modules.triggerBot = v,
            Setting.bool("Игроки", () -> Modules.triggerPlayers, v -> Modules.triggerPlayers = v));
        add(Cat.COMBAT, "Aim Assist", () -> Modules.aimAssist, v -> Modules.aimAssist = v,
            Setting.num("Дальность", 2, 6, 0.5, () -> Modules.aimRange, v -> Modules.aimRange = v),
            Setting.num("Скорость", 1, 30, 1, () -> Modules.aimSpeed, v -> Modules.aimSpeed = v),
            Setting.bool("Игроки", () -> Modules.aimPlayers, v -> Modules.aimPlayers = v));
        add(Cat.COMBAT, "Auto Weapon", () -> Modules.autoWeapon, v -> Modules.autoWeapon = v);
        add(Cat.COMBAT, "Auto Totem", () -> Modules.autoTotem, v -> Modules.autoTotem = v,
            Setting.num("Задержка (тики)", 1, 20, 1, () -> Modules.totemDelay, v -> Modules.totemDelay = (int) v));

        add(Cat.COMBAT, "Auto Gapple", () -> Modules.autoGapple, v -> Modules.autoGapple = v,
            Setting.num("Здоровье", 2, 18, 1, () -> Modules.gappleHealth, v -> Modules.gappleHealth = v));

        // ---------- MOVEMENT ----------
        add(Cat.MOVEMENT, "Sprint", () -> Modules.sprint, v -> Modules.sprint = v);
        add(Cat.MOVEMENT, "Speed", () -> Modules.speed, v -> Modules.speed = v,
            Setting.num("Множитель", 1.05, 2.0, 0.05, () -> Modules.speedMult, v -> Modules.speedMult = v));
        add(Cat.MOVEMENT, "Step", () -> Modules.step, v -> Modules.step = v,
            Setting.num("Высота", 1.0, 2.5, 0.5, () -> Modules.stepHeight, v -> Modules.stepHeight = v));
        add(Cat.MOVEMENT, "Fly", () -> Modules.fly, v -> Modules.fly = v,
            Setting.num("Скорость", 0.05, 1.0, 0.05, () -> Modules.flySpeed, v -> Modules.flySpeed = (float) v));
        add(Cat.MOVEMENT, "Auto Jump", () -> Modules.autoJump, v -> Modules.autoJump = v);
        add(Cat.MOVEMENT, "Bunny Hop", () -> Modules.bunnyHop, v -> Modules.bunnyHop = v);
        add(Cat.MOVEMENT, "High Jump", () -> Modules.highJump, v -> Modules.highJump = v,
            Setting.num("Сила", 0.5, 1.5, 0.1, () -> Modules.jumpPower, v -> Modules.jumpPower = v));
        add(Cat.MOVEMENT, "Jesus", () -> Modules.jesus, v -> Modules.jesus = v);
        add(Cat.MOVEMENT, "Spider", () -> Modules.spider, v -> Modules.spider = v);
        add(Cat.MOVEMENT, "Hover", () -> Modules.hover, v -> Modules.hover = v);
        add(Cat.MOVEMENT, "Glide", () -> Modules.glide, v -> Modules.glide = v,
            Setting.num("Падение", 0.02, 0.3, 0.02, () -> Modules.glideFall, v -> Modules.glideFall = v));
        add(Cat.MOVEMENT, "Fast Fall", () -> Modules.fastFall, v -> Modules.fastFall = v,
            Setting.num("Скорость", 0.2, 3.0, 0.2, () -> Modules.fallSpeed, v -> Modules.fallSpeed = v));
        add(Cat.MOVEMENT, "Sneak", () -> Modules.sneak, v -> Modules.sneak = v);
        add(Cat.MOVEMENT, "Elytra Boost", () -> Modules.elytraBoost, v -> Modules.elytraBoost = v,
            Setting.num("Сила", 0.02, 0.2, 0.01, () -> Modules.elytraPower, v -> Modules.elytraPower = v));
        add(Cat.MOVEMENT, "Long Jump", () -> Modules.longJump, v -> Modules.longJump = v,
            Setting.num("Множитель", 1.2, 3.0, 0.2, () -> Modules.ljMult, v -> Modules.ljMult = v));
        add(Cat.MOVEMENT, "Water Speed", () -> Modules.waterSpeed, v -> Modules.waterSpeed = v);
        add(Cat.MOVEMENT, "Fast Ladder", () -> Modules.fastLadder, v -> Modules.fastLadder = v);
        add(Cat.MOVEMENT, "Freecam", () -> Freecam.active,
            v -> { if (v != Freecam.active) Freecam.toggle(Minecraft.getInstance()); },
            Setting.num("Скорость", 0.2, 3.0, 0.2, () -> Freecam.speed, v -> Freecam.speed = v));

        // ---------- PLAYER ----------
        add(Cat.PLAYER, "Auto Eat", () -> Modules.autoEat, v -> Modules.autoEat = v,
            Setting.num("Порог еды", 4, 19, 1, () -> Modules.eatThreshold, v -> Modules.eatThreshold = (int) v));
        add(Cat.PLAYER, "Auto Tool", () -> Modules.autoTool, v -> Modules.autoTool = v);
        add(Cat.PLAYER, "Auto Armor", () -> Modules.autoArmor, v -> Modules.autoArmor = v);
        add(Cat.PLAYER, "Auto Respawn", () -> Modules.autoRespawn, v -> Modules.autoRespawn = v);
        add(Cat.PLAYER, "Chest Stealer", () -> Modules.chestStealer, v -> Modules.chestStealer = v,
            Setting.num("Задержка (тики)", 1, 10, 1, () -> Modules.stealDelay, v -> Modules.stealDelay = (int) v));
        add(Cat.PLAYER, "Inv Cleaner", () -> Modules.invCleaner, v -> Modules.invCleaner = v);

        // ---------- RENDER ----------
        Setting radius = Setting.num("Радиус", 16, 192, 16, () -> Config.radius, v -> Config.radius = (int) v);
        add(Cat.RENDER, "Block ESP", () -> Config.blockEsp, v -> Config.blockEsp = v, radius);
        add(Cat.RENDER, "Block Tracers", () -> Config.blockTracers, v -> Config.blockTracers = v, radius);
        add(Cat.RENDER, "Storage ESP", () -> Config.storageEsp, v -> Config.storageEsp = v, radius);
        add(Cat.RENDER, "Player ESP", () -> Config.playerEsp, v -> Config.playerEsp = v);
        add(Cat.RENDER, "Player Tracers", () -> Config.playerTracers, v -> Config.playerTracers = v);
        add(Cat.RENDER, "Mob ESP", () -> Modules.mobEsp, v -> Modules.mobEsp = v);
        add(Cat.RENDER, "Animal ESP", () -> Modules.animalEsp, v -> Modules.animalEsp = v);
        add(Cat.RENDER, "Item ESP", () -> Modules.itemEsp, v -> Modules.itemEsp = v);
        add(Cat.RENDER, "Fullbright", () -> Modules.fullbright, v -> Modules.fullbright = v);
        add(Cat.RENDER, "Zoom", () -> Modules.zoom, v -> Modules.zoom = v,
            Setting.num("FOV", 10, 60, 5, () -> Modules.zoomFov, v -> Modules.zoomFov = (int) v));
        add(Cat.RENDER, "Mob Tracers", () -> Config.mobTracers, v -> Config.mobTracers = v);
        add(Cat.RENDER, "Item Tracers", () -> Config.itemTracers, v -> Config.itemTracers = v);
        add(Cat.RENDER, "Projectile ESP", () -> Modules.projectileEsp, v -> Modules.projectileEsp = v);
        add(Cat.RENDER, "Vehicle ESP", () -> Modules.vehicleEsp, v -> Modules.vehicleEsp = v);
        add(Cat.RENDER, "FOV Changer", () -> Modules.fovChanger, v -> Modules.fovChanger = v,
            Setting.num("FOV", 30, 110, 5, () -> Modules.fovValue, v -> Modules.fovValue = (int) v));

        // ---------- MISC ----------
        add(Cat.MISC, "HUD", () -> Hud.enabled, v -> Hud.enabled = v,
            Setting.bool("Список модулей", () -> Hud.list, v -> Hud.list = v),
            Setting.bool("Координаты", () -> Hud.coords, v -> Hud.coords = v));
        add(Cat.MISC, "Auto Relog", () -> AutoRelog.enabled, v -> AutoRelog.enabled = v,
            Setting.num("Уровень Y", -64, 320, 1, () -> AutoRelog.yLevel, v -> AutoRelog.yLevel = v),
            Setting.num("Задержка (сек)", 1, 30, 1, () -> AutoRelog.delaySec, v -> AutoRelog.delaySec = (int) v));
        add(Cat.MISC, "Fast Place", () -> Modules.fastPlace, v -> Modules.fastPlace = v);
        add(Cat.MISC, "Auto Walk", () -> Modules.autoWalk, v -> Modules.autoWalk = v);
        add(Cat.MISC, "Auto Mine", () -> Modules.autoMine, v -> Modules.autoMine = v);
        add(Cat.MISC, "Death Coords", () -> Modules.deathCoords, v -> Modules.deathCoords = v);
        add(Cat.MISC, "Target HUD", () -> Hud.targetHud, v -> Hud.targetHud = v);
        add(Cat.MISC, "Armor HUD", () -> Hud.armorHud, v -> Hud.armorHud = v);
        add(Cat.MISC, "Potion HUD", () -> Hud.potionHud, v -> Hud.potionHud = v);
        add(Cat.MISC, "Speedometer", () -> Hud.speedometer, v -> Hud.speedometer = v);
        add(Cat.MISC, "Clock", () -> Hud.clock, v -> Hud.clock = v);
        add(Cat.MISC, "Panic", () -> false, v -> { if (v) panic(); });
    }

    /** Panic: выключает все модули разом. */
    private static void panic() {
        for (Mod m : ALL) if (!m.name.equals("Panic") && m.get.getAsBoolean()) m.set.accept(false);
    }

    // ---------- клавиши ----------

    /** Единственное место, где опрашивается клавиатура (если сигнатура изменится, править здесь). */
    public static boolean isDown(Minecraft mc, int key) {
        return InputConstants.isKeyDown(mc.getWindow(), key);
    }

    public static String keyName(int key) {
        if (key <= 0) return "—";
        String n = InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString();
        return n.length() > 8 ? n.substring(0, 8) : n;
    }

    public static void tickBinds(Minecraft mc) {
        if (mc.level == null) return;
        for (Mod m : ALL) {
            if (m.key <= 0) continue;
            boolean down = isDown(mc, m.key);
            if (mc.screen == null) {
                if (m.hold) { if (down != m.get.getAsBoolean()) m.set.accept(down); }
                else if (down && !m.wasDown) m.toggle();
            }
            m.wasDown = down;
        }
    }

    // ---------- сохранение ----------

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("espmod.properties"); }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) { p.load(in); } catch (IOException e) { return; }
        for (Mod m : ALL) {
            try {
                String k = p.getProperty(m.name + ".key");
                if (k != null) m.key = Integer.parseInt(k);
                m.hold = Boolean.parseBoolean(p.getProperty(m.name + ".hold", "false"));
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v == null) continue;
                    if (s.isBool) s.setBool(Boolean.parseBoolean(v)); else s.setNum(Double.parseDouble(v));
                }
            } catch (NumberFormatException ignored) { }
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Mod m : ALL) {
            p.setProperty(m.name + ".key", String.valueOf(m.key));
            p.setProperty(m.name + ".hold", String.valueOf(m.hold));
            for (Setting s : m.settings)
                p.setProperty(m.name + "." + s.name, s.isBool ? String.valueOf(s.getBool()) : String.valueOf(s.getNum()));
        }
        try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "ESP mod"); } catch (IOException ignored) { }
    }
}
