Установка:
1. Открой https://fabricmc.net/develop , выбери 1.21.11, скачай шаблон проекта (Mojang mappings).
2. Скопируй папку src из этого архива поверх src шаблона (замени fabric.mod.json).
3. Запусти: ./gradlew build  -> jar в build/libs. Положи в mods вместе с Fabric API.

Клавиши: Right Shift - меню, B - Block ESP, P - Player ESP, H - Freecam (меняются в настройках управления, раздел "Разное").
